
<main id="main">
<!-- ======= About Section ======= -->
<section id="about" class="contact">
   <div class="container">
      <div class="col-md-12">
         <br>
         <br>
         <br>
     
          <h3>NEWS</h3>
          <br>
          <br>
          <br>

          <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>

         <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
         <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>

            <div class="row">

        
            <?php foreach ($news as $row): ?>

             <div class="col-md-4">
               <h3><?=$row['title']?></h3>
               <p><?=substr($row['description'],0,100)?></p>
               <a href="<?=base_url()?>news/detail/<?=$row['n_id']?>"><button class="btn btn-danger">Read More</button></a>
             </div>
                 
            <?php endforeach ?>

          </div>


          
      </div>
   </div>
</section>
<!-- End About Section -->
