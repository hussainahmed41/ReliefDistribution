﻿
      
		<div id="page-wrapper">
		  <div class="header"> 
                        <h1 class="page-header">
                            Dashboard <small> User</small>
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="#">Home</a></li>
					  <li><a href="#">Relief</a></li>
					  <li class="active">View Relief Request</li>
					</ol> 
									
		</div>
            <div id="page-inner">

                <!-- /. ROW  -->
	  <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Relief Type</th>
                                            <th>Amount</th>
                                            <th>Reason</th>
                                            <th>Attachment</th>
                                              <th>Collection Address</th>
                                            
                                           
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    	<?php foreach ($relief as $row){ ?>
                                    		
                                    	
                                        <tr class="odd gradeX">
                                            <td><?=$row['relief_type']?></td>
                                            <td><?=$row['rq_amount']?></td>
                                            <td><?=$row['reason']?></td>

                                             <td>
                                                <?php 

                                                    $attachment = $this->db->get('tbl_attachment')->result_array();

                                                    if ( $attachment ) {
                                                       
                                                   
                                                    $i=1;
                                                    foreach ($attachment as $value) {
                                                        echo '<a href="'.base_url().'img/'.$value['file_path'].'"> Attachment '.$i.'</a><br>';

                                                         $i++;
                                                    }

                                                     }

                                                 ?>


                                            </td>
                                             <?php  if($row['approve']==1){ ?> 
                                             <td> Please Collect your aid from Relief Dutribution Office,<?=$row['area_name']?>,Bangladesh.</td>
                                            <?php }else{  ?>
                                            <td></td>
                                            <?php }  ?>
                                            
                                            
                                            <td>
                                                 <?php if($row['approve']==0){ echo 'Requested'; }else if($row['approve']==1){ echo 'Approved'; }elseif($row['approve']==2){ echo 'Rejected'; } ?>
                                            </td>
                                             
                                        </tr>

                                        <?php } ?>
                                         
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
	 
			
		
			 
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
   