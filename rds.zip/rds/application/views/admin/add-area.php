﻿
      
		<div id="page-wrapper">
		  <div class="header"> 
                        <h1 class="page-header">
                            Dashboard <small> Admin</small>
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="#">Home</a></li>
					  <li><a href="#">Area</a></li>
					  <li class="active">Add Area</li>
					</ol> 
									
		</div>
            <div id="page-inner">

                <!-- /. ROW  -->
	  <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        
                        <div class="panel-body">
                            <div class="col-md-6">
                            <form action="" method="post" enctype="multipart/form-data" >
                                <?php echo $this->session->flashdata('message'); ?>
                           
                             
                                <div class="form-group">
                                   <label for="">Area name</label>
                                   <input type="text" class="form-control input-lg" value="<?=set_value('area_name')?>" placeholder="Area Name" name="area_name">
                                   <div class="error"><?=form_error('area_name')?></div>
                                </div>
                             
                                 
                              
                                <br>
                                <div class="form-group"> 
                                   <button type="submit" class="btn btn-danger">Add Area</button>
                                </div>
                                
                             </form>
                             </div>
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
	 
			
		
			 
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
   