﻿
      
		<div id="page-wrapper">
		  <div class="header"> 
                        <h1 class="page-header">
                            Dashboard <small> Admin</small>
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="#">Home</a></li>
					  <li><a href="#">Relief</a></li>
					  <li class="active">View Relief Request</li>
					</ol> 
									
		</div>
            <div id="page-inner">

                <!-- /. ROW  -->
	  <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Mobile</th>
                                            <th>Dob</th>
                                            <th>Image</th>
                                            <th>NID</th>
                                            <th>Address</th>
                                            <th>Relief Type</th>
                                            <th>Amount</th>
                                            <th>Reason</th>
                                            <th>Attachment</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    	<?php foreach ($relief as $row){ ?>
                                    		
                                    	
                                        <tr class="odd gradeX">
                                            <td><?=$row['name']?></td>
                                            <td><?=$row['mobile']?></td>
                                            <td><?=$row['dob']?></td>
                                            <td><a href="<?=base_url()?>img/<?=$row['picture']?>">VIEW NOW</a></td>
                                            <td><a href="<?=base_url()?>img/<?=$row['nid_file']?>">VIEW NOW</a></td>
                                            <td><?=$row['address']?></td>
                                            <td><?=$row['relief_type']?></td>
                                            <td><?=$row['rq_amount']?></td>
                                            <td><?=$row['reason']?></td>

                                           
                                             <td>
                                                <?php 

                                                    $attachment = $this->db->get('tbl_attachment')->result_array();

                                                    if ( $attachment ) {
                                                       
                                                   
                                                    $i=1;
                                                    foreach ($attachment as $value) {
                                                        echo '<a href="'.base_url().'img/'.$value['file_path'].'"><p> Attachment '.$i.' </p></a>';

                                                         $i++;
                                                    }

                                                     }

                                                 ?>


                                            </td>
                                            
                                            
                                            <td>
                                                <a href="<?=base_url()?>Admin/approve-request/1/<?=$row['rq_id']?>"><button class="btn btn-success">Approve</button></a>  
                                                <a href="<?=base_url()?>Admin/approve-request/2/<?=$row['rq_id']?>"><button class="btn btn-danger">Reject</button></a>
                                            </td>
                                             
                                        </tr>

                                        <?php } ?>
                                         
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
	 
			
		
			 
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
   