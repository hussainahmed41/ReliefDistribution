﻿
      
		<div id="page-wrapper">
		  <div class="header"> 
                        <h1 class="page-header">
                            Dashboard <small> Admin</small>
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="#">Home</a></li>
					  <li><a href="#">Relife</a></li>
					  <li class="active">Edit relief type</li>
					</ol> 
									
		</div>
            <div id="page-inner">

                <!-- /. ROW  -->
	  <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        
                        <div class="panel-body">
                            <div class="col-md-6">
                            <form action="" method="post" enctype="multipart/form-data" >
                                <?php echo $this->session->flashdata('message'); ?>
                           
                             
                                <div class="form-group">
                                   <label for="">relief Title</label>
                                   <input type="text" class="form-control input-lg" value="<?php if(set_value('relief_type')){ echo set_value('relief_type'); }else{ echo  $relief['relief_type']; }?>" placeholder="relief Title" name="relief_type">
                                   <div class="error"><?=form_error('relief_type')?></div>
                                </div>

                                 <div class="form-group">
                                   <label for="">relief Description</label>
                                   <textarea name="attachment_text" class="form-control input-lg"><?php if(set_value('attachment_text')){ echo set_value('attachment_text'); }else{ echo  $relief['attachment_text']; }?></textarea>
                                   <div class="error"><?=form_error('attachment_text')?></div>
                                </div>
                             
                                 
                              
                                <br>
                                <div class="form-group"> 
                                   <button type="submit" class="btn btn-danger">Update Relief Type</button>
                                </div>
                                
                             </form>
                             </div>
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
	 
			
		
			 
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
   