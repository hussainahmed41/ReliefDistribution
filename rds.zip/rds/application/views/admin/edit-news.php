﻿
      
		<div id="page-wrapper">
		  <div class="header"> 
                        <h1 class="page-header">
                            Dashboard <small> Admin</small>
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="#">Home</a></li>
					  <li><a href="#">News</a></li>
					  <li class="active">Add News</li>
					</ol> 
									
		</div>
            <div id="page-inner">

                <!-- /. ROW  -->
	  <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        
                        <div class="panel-body">
                            <div class="col-md-6">
                            <form action="" method="post" enctype="multipart/form-data" >
                                <?php echo $this->session->flashdata('message'); ?>
                           
                             
                                <div class="form-group">
                                   <label for="">News Title</label>
                                   <input type="text" class="form-control input-lg" value="<?php if(set_value('title')){ echo set_value('title'); }else{ echo  $news['title']; }?>" placeholder="News Title" name="title">
                                   <div class="error"><?=form_error('title')?></div>
                                </div>

                                 <div class="form-group">
                                   <label for="">News Description</label>
                                   <textarea name="description" class="form-control input-lg"><?php if(set_value('description')){ echo set_value('description'); }else{ echo  $news['description']; }?></textarea>
                                   <div class="error"><?=form_error('description')?></div>
                                </div>
                             
                                 
                              
                                <br>
                                <div class="form-group"> 
                                   <button type="submit" class="btn btn-danger">Update News</button>
                                </div>
                                
                             </form>
                             </div>
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
	 
			
		
			 
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
   