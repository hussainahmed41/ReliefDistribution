 <!-- jQuery Js -->
    <script src="<?=base_url()?>assets/admin/js/jquery-1.10.2.js"></script>
    <!-- Bootstrap Js -->
    <script src="<?=base_url()?>assets/admin/js/bootstrap.min.js"></script>
	 
    <!-- Metis Menu Js -->
    <script src="<?=base_url()?>assets/admin/js/jquery.metisMenu.js"></script>
     <script src="<?=base_url()?>assets/admin/js/dataTables/jquery.dataTables.js"></script>
        <script src="<?=base_url()?>assets/admin/js/dataTables/dataTables.bootstrap.js"></script>
            <script>
                $(document).ready(function () {
                    $('#dataTables-example').dataTable();
                });
        </script>
  
	 
    <script src="<?=base_url()?>assets/admin/js/custom-scripts.js"></script>

      
    <!-- Chart Js -->

</body>

</html>