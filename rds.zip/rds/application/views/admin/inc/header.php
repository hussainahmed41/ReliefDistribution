<!DOCTYPE html>
<!-- 
Template Name: BRILLIANT Bootstrap Admin Template
Version: 4.5.6
Author: WebThemez
Website: http://www.webthemez.com/ 
-->
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta content="" name="description" />
    <meta content="webthemez" name="author" />
    <title>RDS</title>
    <!-- Bootstrap Styles-->
    <link href="<?=base_url()?>assets/admin/css/bootstrap.css" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="<?=base_url()?>assets/admin/css/font-awesome.css" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="<?=base_url()?>assets/admin/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="<?=base_url()?>assets/admin/css/custom-styles.css" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="<?=base_url()?>assets/admin/js/Lightweight-Chart/cssCharts.css"> 
    <link href="<?=base_url()?>assets/admin/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
   
</head>



<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?=base_url()?>Admin"><strong> RDS</strong></a>
                
        <div id="sideNav" href="">
        <i class="fa fa-bars icon"></i> 
        </div>
            </div>

            <ul class="nav navbar-top-links navbar-right">
                 
                
               
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="<?=base_url()?>Admin/settings"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="<?=base_url()?>Admin/settings"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="<?=base_url()?>Logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                   <!--  <li>
                        <a  href="<?=base_url()?>Admin"><i class="fa fa-dashboard"></i> Dashboard</a>
                    </li> -->
                    
                     
                     <li>
                        <a href="<?=base_url()?>Admin"><i class="fa fa-user"></i> User<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="<?=base_url()?>Admin/view-user">View User</a>
                            </li>
                             
                        </ul>
                    </li> 


                    <li>
                        <a href="<?=base_url()?>Admin"><i class="fa fa-map-marker"></i> Area<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="<?=base_url()?>Admin/add-area">Add Area</a>
                            </li>

                            <li>
                                <a href="<?=base_url()?>Admin/view-area">View Area</a>
                            </li>
                             
                        </ul>
                    </li>  


                    <li>
                        <a href="<?=base_url()?>Admin"><i class="fa fa-picture-o"></i> Gallery<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="<?=base_url()?>Admin/add-gallery">Add Gallery</a>
                            </li>

                            <li>
                                <a href="<?=base_url()?>Admin/view-gallery">View Gallery</a>
                            </li>
                             
                        </ul>
                    </li> 


                    <li>
                        <a href="<?=base_url()?>Admin"><i class="fa fa-file-text"></i> News<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="<?=base_url()?>Admin/add-news">Add News</a>
                            </li>

                            <li>
                                <a href="<?=base_url()?>Admin/view-news">View News</a>
                            </li>
                             
                        </ul>
                    </li> 


                     <li>
                        <a href="<?=base_url()?>Admin"><i class="fa fa-list"></i> Relief Type<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="<?=base_url()?>Admin/add-relief-type">Add Relief Type</a>
                            </li>

                            <li>
                                <a href="<?=base_url()?>Admin/view-relief-type">View Relief Type</a>
                            </li>
                             
                        </ul>
                    </li> 


                    <li>
                        <a href="<?=base_url()?>Admin"><i class="fa fa-medkit"></i> Relief <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            
                            <li>
                                <a href="<?=base_url()?>Admin/view-relief-request">View Relief Request</a>
                            </li>

                            <li>
                                <a href="<?=base_url()?>Admin/view-approved-request">View Approved Request</a>
                            </li>

                            <li>
                                <a href="<?=base_url()?>Admin/view-rejected-request">View Rejected Request</a>
                            </li>


                             <li>
                                <a href="<?=base_url()?>Admin/add-relief-distribution">Add Relief distribution</a>
                            </li>

                             <li>
                                <a href="<?=base_url()?>Admin/view-relief">View Relief</a>
                            </li>

                            <li>
                                <a href="<?=base_url()?>Admin/view-relief-distribution">View Relief distribution</a>
                            </li>
                             
                        </ul>
                    </li> 


                    <li>
                        <a href="<?=base_url()?>Admin"><i class="fa fa-check-square-o"></i> Relief Pattern<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="<?=base_url()?>Admin/add-relief-pattern">Add Relief Pattern</a>
                            </li>

                            <li>
                                <a href="<?=base_url()?>Admin/view-relief-pattern">View Relief Pattern</a>
                            </li>
                             
                        </ul>
                    </li> 


                     
                    <?php if($this->session->userdata('type')=='superadmin'){  ?>

                    <li>
                        <a href="<?=base_url()?>Admin"><i class="fa fa-arrows"></i> Admin<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="<?=base_url()?>Admin/add-admin">Add Admin</a>
                            </li>

                            <li>
                                <a href="<?=base_url()?>Admin/view-admin">View Admin</a>
                            </li>
                             
                        </ul>
                    </li>    
                    

                    <?php } ?>
                    <li>
                        <a href="<?=base_url()?>Admin/settings"><i class="fa fa-cog"></i> Settings</a>
                         
                    </li>   
                    
                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->