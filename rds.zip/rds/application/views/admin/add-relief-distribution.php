﻿
      
		<div id="page-wrapper">
		  <div class="header"> 
                        <h1 class="page-header">
                            Dashboard <small> Admin</small>
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="#">Home</a></li>
					  <li><a href="#">Area</a></li>
					  <li class="active">Add Relief Distribution</li>
					</ol> 
									
		</div>
            <div id="page-inner">

                <!-- /. ROW  -->
	  <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        
                        <div class="panel-body">
                            <div class="col-md-6">

                                <form action="" method="post" enctype="multipart/form-data">
                                     <?php echo $this->session->flashdata('message'); ?>

                                    
                                    <div class="form-group">
                                        
                                     <input type="text" name="particular" class="form-control" value="<?=set_value('particular')?>" placeholder="particular">

                                    </div>
                                    <div class="error"><?=form_error('particular')?></div>
                                  

                                    <div class="form-group">
                                        
                                     <input type="text" name="amount" class="form-control" value="<?=set_value('amount')?>" placeholder="Amount">

                                    </div>
                                    <div class="error"><?=form_error('amount')?></div>
                                
                                  

                                      <div class="form-group">
                                       
                                    
                                      <select name="relief_pattern" class="form-control" >
                                          <option value="">---select pattern---</option>
                                          <?php foreach ($relief_pattern as $row) {  ?>
                                            <option value="<?=$row['relief_pattern']?>"><?=$row['relief_pattern']?></option>
                                         <?php } ?>
                                      </select>
                                     
                                    </div>

                                    <div class="error"><?=form_error('relief_pattern')?></div>




                                     <div class="form-group">
                                       
                                    
                                      <select name="area_id" class="form-control" >
                                          <option value="">---select area---</option>
                                          <?php foreach ($area as $row) {  ?>
                                            <option value="<?=$row['a_id']?>"><?=$row['area_name']?></option>
                                         <?php } ?>
                                      </select>
                                     
                                    </div>
                                    <div class="error"><?=form_error('area_id')?></div>

                                    

                                    <div class="form-group">
                                      <br>
                                      <button class="btn btn-danger" type="submit">Add Now</button>

                                    </div>

                                   </form>
                            
                            </div>
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
	 
			
		
			 
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
   