﻿
      
		<div id="page-wrapper">
		  <div class="header"> 
                        <h1 class="page-header">
                            Dashboard <small> Admin</small>
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="#">Home</a></li>
					  <li><a href="#">Area</a></li>
					  <li class="active">View Relief</li>
					</ol> 
									
		</div>
            <div id="page-inner">

                <!-- /. ROW  -->
	  <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Relief Distribution
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>User Name</th>
                                            <th>User Mobile</th>
                                            <th>Particular</th>
                                            <th>Amount</th>
                                            <th>Pattern</th>
                                            <th>Area</th>
                                             
                                        </tr>
                                    </thead>
                                    <tbody>
                                    	<?php foreach ($relief as $row){ ?>
                                    		
                                    	
                                        <tr class="odd gradeX">
                                            <td><?=$row['rds_id']?></td>
                                            <td><?=$row['name']?></td>
                                            <td><?=$row['mobile']?></td>
                                          
                                            <td><?=$row['particular']?></td>
                                            <td><?=$row['amount']?></td>
                                            <td><?=$row['relief_pattern']?></td>
                                            <td><?=$row['area_name']?></td>
                                        
                                            
                                             
                                        </tr>

                                        <?php } ?>
                                         
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
	 
			
		
			 
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
   