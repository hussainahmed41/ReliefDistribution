﻿

      
		<div id="page-wrapper">
		  <div class="header"> 
                        <h1 class="page-header">
                            Dashboard <small> Admin</small>
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="#">Home</a></li>
					  <li><a href="#">User</a></li>
					  <li class="active">Settings</li>
					</ol> 
									
		</div>
            <div id="page-inner">

                <!-- /. ROW  -->
	  <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                              
                        </div>
                        <div class="panel-body">
                            <div class="col-md-6">


						         <form action="" method="post" enctype="multipart/form-data" >
						            <?php echo $this->session->flashdata('message'); ?>
						            <div class="form-group">
						               <label for="">Name</label>
						               <input type="text" class="form-control input-lg" value="<?php if(set_value('user_name')){ echo set_value('user_name'); }else{ echo  $user['name']; }?>" placeholder="User Name" name="user_name">
						               <div class="error"><?=form_error('user_name')?></div>
						            </div>
						         
						            <div class="form-group">
						               <label for="">User Name</label>
						               <input type="text" class="form-control input-lg" value="<?php if(set_value('mobile')){ echo set_value('mobile'); }else{ echo  $user['mobile']; }?>" placeholder="User Mobile" name="mobile">
						               <div class="error"><?=form_error('mobile')?></div>
						            </div>
						         
						            <div class="form-group">
						               <label for="">Pasword</label>
						               <input type="password" class="form-control input-lg" value="<?php if(set_value('password')){ echo set_value('password'); }else{ echo  $user['password']; }?>" placeholder="User Pasword" name="password">
						               <div class="error"><?=form_error('password')?></div>
						            </div>
						         
						            <div class="form-group">
						               <label for="">Verify Password</label>
						               <input type="password" class="form-control input-lg" value="<?php if(set_value('v_password')){ echo set_value('v_password'); }else{ echo  $user['password']; }?>" placeholder="Verify Pasword" name="v_password">
						               <div class="error"><?=form_error('v_password')?></div>
						            </div>
						         
						            
						            <br>
						            <div class="form-group"> 
						               <button type="submit" class="btn btn-danger">Update Now</button>
						            </div>
						            
						         </form>
                             
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
	 
			
		
			 
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
   