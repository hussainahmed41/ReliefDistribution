﻿
      
		<div id="page-wrapper">
		  <div class="header"> 
                        <h1 class="page-header">
                            Dashboard <small> Admin</small>
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="#">Home</a></li>
					  <li><a href="#">User</a></li>
					  <li class="active">Edit User</li>
					</ol> 
									
		</div>
            <div id="page-inner">

                <!-- /. ROW  -->
	  <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Advanced Tables
                        </div>
                        <div class="panel-body">
                            <div class="col-md-6">


						         <form action="" method="post" enctype="multipart/form-data" >
						            <?php echo $this->session->flashdata('message'); ?>
						            <div class="form-group">
						               <label for="">Name</label>
						               <input type="text" class="form-control input-lg" value="<?php if(set_value('user_name')){ echo set_value('user_name'); }else{ echo  $user['name']; }?>" placeholder="User Name" name="user_name">
						               <div class="error"><?=form_error('user_name')?></div>
						            </div>
						         
						            <div class="form-group">
						               <label for="">Mobile</label>
						               <input type="text" class="form-control input-lg" value="<?php if(set_value('mobile')){ echo set_value('mobile'); }else{ echo  $user['mobile']; }?>" placeholder="User Mobile" name="mobile">
						               <div class="error"><?=form_error('mobile')?></div>
						            </div>
						         
						            <div class="form-group">
						               <label for="">Pasword</label>
						               <input type="password" class="form-control input-lg" value="<?php if(set_value('password')){ echo set_value('password'); }else{ echo  $user['password']; }?>" placeholder="User Pasword" name="password">
						               <div class="error"><?=form_error('password')?></div>
						            </div>
						         
						            <div class="form-group">
						               <label for="">Verify Password</label>
						               <input type="password" class="form-control input-lg" value="<?php if(set_value('v_password')){ echo set_value('v_password'); }else{ echo  $user['password']; }?>" placeholder="Verify Pasword" name="v_password">
						               <div class="error"><?=form_error('v_password')?></div>
						            </div>
						         
						            <div class="form-group">
						               <label for="">DOB</label>
						               <input type="date" class="form-control input-lg" value="<?php if(set_value('date_of_birth')){ echo set_value('date_of_birth'); }else{ echo  $user['dob']; }?>" placeholder="User DOB" name="date_of_birth">
						               <div class="error"><?=form_error('date_of_birth')?></div>
						            </div>


						            <div class="form-group">
						               <label for="">Address</label>
						                
						               <textarea class="form-control input-lg" placeholder="Address" name="address" ><?php if(set_value('address')){ echo set_value('address'); }else{ echo  $user['address']; }?></textarea>
						               <div class="error"><?=form_error('address')?></div>
						            </div>
						         
						            <div class="form-group">
						               <label for="">Area</label>
						           
						               <select name="area_id" class="form-control input-lg"  >
						                  <option value="">--select area--</option>
						                  <?php foreach ($area as $row) {  ?>
						                  <option  <?php  if(set_value('area_id')==$row['a_id']) { echo 'selected'; }else if($user['area_id']==$row['a_id']){ echo 'selected';  } ?>  value="<?=$row['a_id']?>"><?=$row['area_name']?></option>
						                  <?php  } ?>
						               </select>
						               <div class="error"><?=form_error('area_id')?></div>
						            </div>
						         
						            <div class="form-group"> 
						               <label for=""> Photo</label>

						               <br>
						               <?php if($user['picture']){ ?>
						               <img style="width:150px;height: 150px;" src="<?=base_url()?>img/<?=$user['picture']?>" alt="">
						          	   <?php } ?>
						               <br>
						               <br>
						               <input type="file" name="user_image">
						            </div>
						            <br>
						            <div class="form-group"> 
						               <button type="submit" class="btn btn-danger">Edit Now</button>
						            </div>
						            
						         </form>
                             
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
	 
			
		
			 
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
   