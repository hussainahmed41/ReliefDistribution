﻿
      
		<div id="page-wrapper">
		  <div class="header"> 
                        <h1 class="page-header">
                            Dashboard <small> Admin</small>
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="#">Home</a></li>
					  <li><a href="#">Gallery</a></li>
					  <li class="active">View Gallery</li>
					</ol> 
									
		</div>
            <div id="page-inner">

                <!-- /. ROW  -->
	  <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Advanced Tables
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>Image</th>
                                            <th>Action</th>
                                         
                                        </tr>
                                    </thead>
                                    <tbody>
                                    	<?php $i=1; foreach ($gallery as $row){ ?>
                                    		
                                    	
                                        <tr class="odd gradeX">
                                            <td><?=$i?></td>
                                            <td><img style="width: 150px;height: 130px;"src="<?=base_url()?>img/<?=$row['g_image']?>" alt=""></td>
                                            
                                            <td>
                                                <a href="<?=base_url()?>Admin/edit-gallery/<?=$row['g_id']?>"><button class="btn btn-primary">Edit</button></a>
                                                <a href="<?=base_url()?>Admin/delete-gallery/<?=$row['g_id']?>"><button class="btn btn-danger">Delete</button></a>
                                            </td>
                                             
                                        </tr>

                                        <?php  $i++; } ?>
                                         
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
	 
			
		
			 
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
   