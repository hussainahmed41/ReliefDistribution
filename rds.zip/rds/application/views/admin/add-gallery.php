﻿
      
		<div id="page-wrapper">
		  <div class="header"> 
                        <h1 class="page-header">
                            Dashboard <small> Admin</small>
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="#">Home</a></li>
					  <li><a href="#">Gallery</a></li>
					  <li class="active">Add Gallery</li>
					</ol> 
									
		</div>
            <div id="page-inner">

                <!-- /. ROW  -->
	  <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Add Gallery
                        </div>
                        <div class="panel-body">
                            <div class="col-md-6">


						         <form action="" method="post" enctype="multipart/form-data" >
						            <?php echo $this->session->flashdata('message'); ?>
						            
						            <div class="form-group"> 
						               <label for=""> Image</label>
						               <br>
						               <input type="file" name="user_image">
						            </div>
						            <br>
						            <div class="form-group"> 
						               <button type="submit" class="btn btn-danger">Add Now</button>
						            </div>
						            
						         </form>
                             
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
	 
			
		
			 
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
   