﻿
      
		<div id="page-wrapper">
		  <div class="header"> 
                        <h1 class="page-header">
                            Dashboard <small> Admin</small>
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="#">Home</a></li>
					  <li><a href="#">Area</a></li>
					  <li class="active">View Relief Type</li>
					</ol> 
									
		</div>
            <div id="page-inner">

                <!-- /. ROW  -->
	  <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Relief Type List
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>Name</th>
                                            <th>Attachment text</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    	<?php foreach ($relief_type as $row){ ?>
                                    		
                                    	
                                        <tr class="odd gradeX">
                                            <td><?=$row['rt_id']?></td>
                                            <td><?=$row['relief_type']?></td>
                                            <td><?=$row['attachment_text']?></td>
                                            <td>
                                            <a href="<?=base_url()?>Admin/edit-relief-type/<?=$row['rt_id']?>"><button class="btn btn-primary">Edit</button></a>
                                            <a href="<?=base_url()?>Admin/delete-relief-type/<?=$row['rt_id']?>"><button class="btn btn-danger">Delete</button></a>

                                            </td>
                                             
                                        </tr>

                                        <?php } ?>
                                         
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
	 
			
		
			 
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
   