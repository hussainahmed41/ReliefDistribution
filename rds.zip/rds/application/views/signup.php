<main id="main">
<!-- ======= About Section ======= -->
<section id="about" class="contact">
   <div class="container">
      <div class="col-md-6 offset-md-3 py-5">
     
     
          <h3>Signup</h3>
         <form action="" method="post" enctype="multipart/form-data" >
            <?php echo $this->session->flashdata('message'); ?>
            <div class="form-group">
               <label for="">Name</label>
               <input type="text" class="form-control input-lg" value="<?=set_value('user_name')?>" placeholder="User Name" name="user_name">
               <div class="error"><?=form_error('user_name')?></div>
            </div>
         
            <div class="form-group">
               <label for="">Mobile</label>
               <input type="text" class="form-control input-lg" value="<?=set_value('mobile')?>" placeholder="User Mobile" name="mobile">
               <div class="error"><?=form_error('mobile')?></div>
            </div>
         
            <div class="form-group">
               <label for="">Pasword</label>
               <input type="password" class="form-control input-lg" value="<?=set_value('password')?>" placeholder="User Pasword" name="password">
               <div class="error"><?=form_error('password')?></div>
            </div>
         
            <div class="form-group">
               <label for="">Verify Password</label>
               <input type="password" class="form-control input-lg" value="<?=set_value('v_password')?>" placeholder="Verify Pasword" name="v_password">
               <div class="error"><?=form_error('v_password')?></div>
            </div>
         
            <div class="form-group">
               <label for="">DOB</label>
               <input type="date" class="form-control input-lg" value="<?=set_value('date_of_birth')?>" placeholder="User DOB" name="date_of_birth">
               <div class="error"><?=form_error('date_of_birth')?></div>
            </div>


            <div class="form-group">
               <label for="">Address</label>
                
               <textarea class="form-control input-lg" placeholder="Address" name="address" ><?=set_value('address')?></textarea>
               <div class="error"><?=form_error('address')?></div>
            </div>
         
            <div class="form-group">
               <label for="">Area</label>
           
               <select name="area_id" class="form-control input-lg"  >
                  <option value="">--select area--</option>
                  <?php foreach ($area as $row) {  ?>
                  <option  <?php  if(set_value('area_id')==$row['a_id']) { echo 'selected'; } ?>  value="<?=$row['a_id']?>"><?=$row['area_name']?></option>
                  <?php  } ?>
               </select>
               <div class="error"><?=form_error('area_id')?></div>
            </div>
         
            <div class="form-group"> 
               <label for="">Add Photo</label>
               <br>
               <input type="file" name="user_image">
            </div>
            <br>
            <div class="form-group"> 
               <label for="">Add NID</label>
               <br>
               <input type="file" name="user_nid">
            </div>

            <br>
            <div class="form-group"> 
               <button type="submit" class="btn btn-danger">Signup Now</button>
            </div>
            
         </form>
      </div>
   </div>
</section>
<!-- End About Section -->
