
<main id="main">
<!-- ======= About Section ======= -->
<section id="about" class="contact">
   <div class="container">
      <div class="col-md-6 offset-md-3 py-5">
     
     
          <h3>Login</h3>
         <form action="" method="post" enctype="multipart/form-data" >
            <?php echo $this->session->flashdata('message'); ?>
       
         
            <div class="form-group">
               <label for="">Mobile</label>
               <input type="text" class="form-control input-lg" value="<?=set_value('mobile')?>" placeholder="User Mobile" name="mobile">
               <div class="error"><?=form_error('mobile')?></div>
            </div>
         
            <div class="form-group">
               <label for="">Pasword</label>
               <input type="password" class="form-control input-lg" value="<?=set_value('password')?>" placeholder="User Pasword" name="password">
               <div class="error"><?=form_error('password')?></div>
            </div>
          
            <br>
            <div class="form-group"> 
               <button type="submit" class="btn btn-danger">Login Now</button>
            </div>
            
         </form>
      </div>
   </div>
</section>
<!-- End About Section -->
