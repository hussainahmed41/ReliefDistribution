  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

      <div class="carousel-inner" role="listbox">

        <!-- Slide 1 -->
        <div class="carousel-item active" style="background-image: url(<?=base_url()?>assets/img/slide/slide-1.jpg)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">Welcome to <span>Relief Distibution System</span></h2>
              <p class="animate__animated animate__fadeInUp">Sign up as User with your information and get benifuted</p>
              <a href="<?=base_url()?>SignUp" class="btn-get-started animate__animated animate__fadeInUp scrollto">Sign Up Now</a>
            </div>
          </div>
        </div>

        <!-- Slide 2 -->
        <div class="carousel-item" style="background-image: url(<?=base_url()?>assets/img/slide/slide-2.jpg)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">Smart Allocation</h2>
              <p class="animate__animated animate__fadeInUp">Sign up as User with your information and get your aid smartly allocated</p>
              <a href="<?=base_url()?>SignUp" class="btn-get-started animate__animated animate__fadeInUp scrollto">Sign Up Now</a>
            </div>
          </div>
        </div>

        <!-- Slide 3 -->
        <div class="carousel-item" style="background-image: url(<?=base_url()?>assets/img/slide/slide-3.jpg)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">Truthfulness</h2>
              <p class="animate__animated animate__fadeInUp">Everything is open and Accepted to all for its clarity</p>
               <a href="<?=base_url()?>SignUp" class="btn-get-started animate__animated animate__fadeInUp scrollto">Sign Up Now</a>
            </div>
          </div>
        </div>

      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
      </a>

    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="row content">
          <div class="col-lg-6">
            <h2>The main aim of Relief Distribution System</h2>
            <h3>To distribute the things perfectly and easily with this application </h3>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
            <p>
              There are so many Union and Word sector in our Country connected with the Upozila dept. Sometimes Govt. helps the people of country via Member ,Chairmen,MP,councilor,mayor  through distributing cash money,rice,flour,seeds,land,wheat and so many things of the Upozila(union,word) Sector.To provide the things to the correct person, it's hard to do and matter of time and also lack of measurements.
            </p>
            <ul>
              <li><i class="ri-check-double-line"></i>This paperwill provide a clear understanding about the status quo of government in time of providing services to the citizen of Bangladesh.  </li>
              <li><i class="ri-check-double-line"></i> It also identifies the problems of implementing government by the government in different sectors in time of providing service to the people.</li>
              <li><i class="ri-check-double-line"></i> This system also finds that how these problems become the burdens for the mass people to get the services from this government office.</li>
            </ul>
            <p class="font-italic">
              The use of modern technology like computers and access of the internet by the mass people are the main equipments for ensuring  government.They are using manual or traditional application process still now, and manual process makes the whole application process complex and difficult for its service receiver. government is the only solution to ensure effectiveness, efficiency, accountability and transparency of the government in time of providing services to the people.
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="row">
          <div class="col-md-6">
            <div class="icon-box">
              <i class="bi bi-briefcase"></i>
              <h4><a href="#">Get AID</a></h4>
              <p>People will get aid perfectly</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="bi bi-card-checklist"></i>
              <h4><a href="#"> Message </a></h4>
              <p>People can request message to admin</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="bi bi-bar-chart"></i>
              <h4><a href="#">Request Form</a></h4>
              <p>User can send request through the form</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="bi bi-binoculars"></i>
              <h4><a href="#">Overview</a></h4>
              <p>People can Overview the site</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="bi bi-brightness-high"></i>
              <h4><a href="#">True distribution</a></h4>
              <p>All relief and aid have true distribution</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="bi bi-calendar4-week"></i>
              <h4><a href="#">Comment</a></h4>
              <p>People can Comment or provide any suggestion</p>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Services Section -->

    
  </main><!-- End #main -->