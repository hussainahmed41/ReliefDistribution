
<main id="main">
<!-- ======= About Section ======= -->
<section id="about" class="contact">
   <div class="container">
      <div class="col-md-12">
         <br>
         <br>
         <br>
     
          <h3>NEWS Detail</h3>
          <br>
          <br>
          <br>

          <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>

         <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
         <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>

            <div class="row">

        
            
             <div class="col-md-12">
               <h3><?=$news['title']?></h3>
               <p><?=$news['description']?></p>

             </div>

             <div class="col-md-6">
               <br>
                <br>
               <h3>Add Comments</h3>
               <form action="" method="post">
                 <?php echo $this->session->flashdata('message'); ?>
                <div class="form-group">
                    
                  <textarea name="comment" class="form-control"><?=set_value('comment')?></textarea>

                </div>
                <div class="error"><?=form_error('comment')?></div>

                <div class="form-group">
                  <br>
                  <button class="btn btn-danger" type="submit">Add Comment</button>

                </div>

               </form>


             </div>
             <?php if($comments){ ?>
              <div class="col-md-7">
               <br>
               <br>
               <h3>Comments:</h3>
               <?php foreach ($comments as $row) {  ?>
                 
             
               <div class="col-md-12">
        
                 <p><b><?=$row['name']?></b>: <?=$row['comment']?></p>
               </div>

              <?php } ?>



              </div>
            <?php } ?>
                 
             

          </div>


          
      </div>
   </div>
</section>
<!-- End About Section -->
