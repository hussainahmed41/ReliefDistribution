<main id="main">
<!-- ======= About Section ======= -->
<section id="about" class="contact">
   <div class="container">
      <div class="col-md-12">
         <br>
         <br>
         <br>
     
          <h3>Gallery</h3>

          <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>

         <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
         <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>


        
            <?php foreach ($gallery as $row): ?>

             
                  <a data-fancybox="gallery" href="<?=base_url()?>img/<?=$row['g_image']?>"><img style="width:200px;height:180px;" src="<?=base_url()?>img/<?=$row['g_image']?>"></a>
                 
            
               
            <?php endforeach ?>

         


          
      </div>
   </div>
</section>
<!-- End About Section -->
