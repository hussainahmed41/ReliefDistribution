
<main id="main">
<!-- ======= About Section ======= -->
<section id="about" class="contact">
   <div class="container">
      <div class="col-md-12">
         <br>
         <br>
         <br>
     
          <h3>Apply For AID</h3>
          <br>
        
           <div class="row">
 
             <div class="col-md-6">
             
               <form action="" method="post" enctype="multipart/form-data">
                 <?php echo $this->session->flashdata('message'); ?>

                <div class="form-group">
                    
                 <input type="text" name="rq_amount" class="form-control" value="<?=set_value('rq_amount')?>" placeholder="Amount">

                </div>
                <div class="error"><?=form_error('rq_amount')?></div>
                <br>
                <div class="form-group">
                    
                  <textarea name="reason" class="form-control" placeholder="Reason of Aid"><?=set_value('reason')?></textarea>

                </div>
                <div class="error"><?=form_error('reason')?></div>
                <br>

                <div class="form-group">

                  <select id="relief_type_id" name="relief_type_id" onchange="loadAidText()" class="form-control" >
                      <option value="">---select aid type---</option>
                      <?php foreach ($relief_type as $row) {  ?>
                        <option value="<?=$row['rt_id']?>"><?=$row['relief_type']?></option>
                     <?php } ?>
                  </select>
                 
                </div>
                <div class="error"><?=form_error('relief_type_id')?></div>

                 <strong>
                 <br>
                 <div class="note-area">
                    Please Select an Aid Type
                  </div>
                 </strong>

                <div class="form-group">
                  <br>
                  <input  type='file' name='files[]' multiple="" >

                </div>

                <div class="form-group">
                  <br>
                  <button class="btn btn-danger" type="submit">Apply Now</button>

                </div>

               </form>


             </div>
             


 

          </div>


          
      </div>
   </div>
</section>
<!-- End About Section -->
 <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>

  <script>
  
function loadAidText(){

var relief_type_id=$('#relief_type_id').val();
var thisurl='<?=base_url()?>Getaid/loadAidText/'+relief_type_id;

  $.get( thisurl, function( data ) {
  $( ".note-area" ).html( data );
  });

}



  </script>