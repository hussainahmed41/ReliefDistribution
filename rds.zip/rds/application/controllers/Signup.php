<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Signup extends CI_Controller {

	
	public function index()
	{
		 

	

		 $this->form_validation->set_rules('user_name', 'User Name', 'required|regex_match[/^[a-zA-Z ]*$/]');
		 $this->form_validation->set_rules('mobile', 'User mobile', 'required|is_unique[tbl_user.mobile]|is_numeric');
 

		$this->form_validation->set_rules('date_of_birth', 'Date Of Birth', 'required|check_date|check_date_of_birth');

		$this->form_validation->set_message('check_date_of_birth','You are Under 18 So Not Allowed to Open Account');
		$this->form_validation->set_message('check_date','Date is In valid please enter yyyy-mm-dd');


		$this->form_validation->set_rules('area_id', 'Area', 'required');
		
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		$this->form_validation->set_rules('v_password', 'Verify password', 'required|matches[password]');
		$this->form_validation->set_rules('address', 'Address', 'required');
		
 
 
		function check_date_of_birth($val){


			$date_of_birth=date('Y-m-d',strtotime($val));

			$then_ts = strtotime($date_of_birth);
			$then_year = date('Y', $then_ts);
			$age = date('Y') - $then_year;
			if(strtotime('+' . $age . ' years', $then_ts) > time()) $age--;

			if($age<18){

			return false;
			}else{
			return true;
			}
			 

		}

		function check_date($val){


 		     return (bool)strtotime($val);


		}

		if ($this->form_validation->run() == FALSE)
		{

		$data['area']=$this->db->order_by('area_name','asc')->get('tbl_area')->result_array();
			
		 	 
		$this->load->view('inc/header');
		$this->load->view('signup',$data);
		$this->load->view('inc/footer');
		 

		}else{

			$idata['name']=$this->input->post('user_name');
			$idata['mobile']=$this->input->post('mobile');
			$idata['dob']=$this->input->post('date_of_birth');
			$idata['password']=$this->input->post('password');
			$idata['address']=$this->input->post('address');
			$idata['area_id']=$this->input->post('area_id');
			$idata['type']='user';

			/////////////////////////---- FILE ADDING CODE -----////////////////////////////


			if(!empty($_FILES) && ($_FILES['user_image']['name'])){
			

			  $config['upload_path'] = 'img/';
			  $config['allowed_types'] = 'gif|jpg|png|jpeg|pdf';
			  $this->load->library('upload', $config);
			   if (!$this->upload->do_upload('user_image')) {
			     $this->session->set_flashdata('message', $this->upload->display_errors());
			 
					redirect('signup');
			 } else {
			  $avatar = $this->upload->data();
			  $user_image = $avatar['file_name'];

			  $idata['picture']=$user_image;
			 }

			}else{
			
			$message='<div class="alert alert-danger">Please Add Your Image</div>';

			$this->session->set_flashdata('message',$message);

			redirect('signup');

			}



			if(!empty($_FILES) && ($_FILES['user_nid']['name'])){
			

			  $config['upload_path'] = 'img/';
			  $config['allowed_types'] = 'gif|jpg|png|jpeg|pdf';
			  $this->load->library('upload', $config);
			   if (!$this->upload->do_upload('user_nid')) {
			     $this->session->set_flashdata('message', $this->upload->display_errors());
			 
					redirect('signup');
			 } else {
			  $avatar = $this->upload->data();
			  $user_nid = $avatar['file_name'];

			  $idata['nid_file']=$user_nid;
			 }

			}else{
			
			$message='<div class="alert alert-danger">Please Add Your NID</div>';

			$this->session->set_flashdata('message',$message);

			redirect('signup');

			}

			/////////////////////////---- FILE ADDING CODE -----////////////////////////////

 
 
			$this->db->insert('tbl_user',$idata);

			$message='<div class="alert alert-success">Account Created Successfully</div>';

			$this->session->set_flashdata('message',$message);

			redirect('signup');

		}
		 

 

		 

	}
	
	 
	
}