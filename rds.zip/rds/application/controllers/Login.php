
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	
	public function index()
	{
		 

	
 
		 $this->form_validation->set_rules('mobile', 'User mobile', 'required');
 

	 	
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		 
		
 
  

		if ($this->form_validation->run() == FALSE)
		{
 	
		 	 
		$this->load->view('inc/header');
		$this->load->view('login');
		$this->load->view('inc/footer');
		 

		}else{
 				

			
				$data['mobile']=$this->input->post('mobile');
				$data['password']=$this->input->post('password');
				
 				
 				$this->db->where('mobile',$data['mobile']);
				$this->db->where('password',$data['password']);
				$result = $this->db->get('tbl_user')->result_array();
				
				if($result){
				

 
				$s_data['type']=$result[0]['type'];
				$s_data['mobile']=$result[0]['mobile'];
				$s_data['id']=$result[0]['id'];
				$s_data['name']=$result[0]['name'];
				$s_data['picture']=$result[0]['picture'];
		 
				$this->session->set_userdata($s_data);
				
				if($s_data['type']=='user'){
				 
					redirect('User');

				}else if($s_data['type']=='superadmin'){
					
				 
					redirect('Admin');
				}else if($s_data['type']=='admin'){
					
				 
					redirect('Admin');
				}

				 

				}else{
					
				
				$msg='<div class="alert alert-danger">Invalid Mobile or Password </div>';
				
				$this->session->set_flashdata('message',$msg);
				
				
				redirect('login');

					
				}

		}
		 

 

		 

	}
	
	 
	
}