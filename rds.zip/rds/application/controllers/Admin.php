<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct() {

        parent::__construct();

		date_default_timezone_set('Asia/Dhaka');
		
        if($this->session->userdata('type')=='superadmin'||$this->session->userdata('type')=='admin'){
			
		}else{
		redirect('welcome');
		}


    }


	public function index()
	{
		 
		$data['area']=$this->db->get('tbl_area')->num_rows();
		$data['user']=$this->db->where('type','user')->get('tbl_user')->num_rows();
		$data['news']=$this->db->get('tbl_news')->num_rows();
		$data['comments']=$this->db->get('tbl_comment')->num_rows();
		 
		$this->load->view('admin/inc/header');
		$this->load->view('admin/dashboard',$data);
		$this->load->view('admin/inc/footer');
		 


	}


	public function view_user()
	{
		 
		$data['user']=$this->db->where('type','user')->get('tbl_user')->result_array();
		 	
		$this->load->view('admin/inc/header');
		$this->load->view('admin/view-user',$data);
		$this->load->view('admin/inc/footer');
		 


	} 

	public function edit_user($id)
	{
		 

	

		 $this->form_validation->set_rules('user_name', 'User Name', 'required|regex_match[/^[a-zA-Z ]*$/]');
		 $this->form_validation->set_rules('mobile', 'User mobile', 'required|is_numeric');
 

		$this->form_validation->set_rules('date_of_birth', 'Date Of Birth', 'required|check_date|check_date_of_birth');

		$this->form_validation->set_message('check_date_of_birth','You are Under 18 So Not Allowed to Open Account');
		$this->form_validation->set_message('check_date','Date is In valid please enter yyyy-mm-dd');


		$this->form_validation->set_rules('area_id', 'Area', 'required');
		
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		$this->form_validation->set_rules('v_password', 'Verify password', 'required|matches[password]');
		$this->form_validation->set_rules('address', 'Address', 'required');
		
 
 
		function check_date_of_birth($val){


			$date_of_birth=date('Y-m-d',strtotime($val));

			$then_ts = strtotime($date_of_birth);
			$then_year = date('Y', $then_ts);
			$age = date('Y') - $then_year;
			if(strtotime('+' . $age . ' years', $then_ts) > time()) $age--;

			if($age<18){

			return false;
			}else{
			return true;
			}
			 

		}

		function check_date($val){


 		     return (bool)strtotime($val);


		}

		if ($this->form_validation->run() == FALSE)
		{

		$data['area']=$this->db->order_by('area_name','asc')->get('tbl_area')->result_array();
		$data['user']=$this->db->where('id',$id)->get('tbl_user')->row_array();
			
		 	 
		$this->load->view('admin/inc/header');
		$this->load->view('admin/edit-user',$data);
		$this->load->view('admin/inc/footer');
		 

		}else{

			$idata['name']=$this->input->post('user_name');
			$idata['mobile']=$this->input->post('mobile');
			$idata['dob']=$this->input->post('date_of_birth');
			$idata['password']=$this->input->post('password');
			$idata['address']=$this->input->post('address');
			$idata['area_id']=$this->input->post('area_id');
			$idata['type']='user';

			/////////////////////////---- FILE ADDING CODE -----////////////////////////////


			if(!empty($_FILES) && ($_FILES['user_image']['name'])){
			

			  $config['upload_path'] = 'img/';
			  $config['allowed_types'] = 'gif|jpg|png|jpeg';
			  $this->load->library('upload', $config);
			   if (!$this->upload->do_upload('user_image')) {
			     $this->session->set_flashdata('message', $this->upload->display_errors());
			 
					redirect('Admin/edit-user/'.$id);
			 } else {
			  $avatar = $this->upload->data();
			  $user_image = $avatar['file_name'];

			  $idata['picture']=$user_image;

			  $old_image=$this->db->where('id',$id)->get('tbl_user')->row_array()['picture'];

			  unlink('img/'.$old_image.'');
		
			 }

			} 

			/////////////////////////---- FILE ADDING CODE -----////////////////////////////

 
 
			$this->db->where('id',$id)->update('tbl_user',$idata);

			$message='<div class="alert alert-success">User Updated Successfully</div>';

			$this->session->set_flashdata('message',$message);

			redirect('Admin/edit-user/'.$id);

		}
		 

 

		 

	}

	public function delete_user($id)
	{
		 
		$data['area']=$this->db->where('id',$id)->get('tbl_user')->result_array();
		 	
		$this->load->view('admin/inc/header');
		$this->load->view('admin/view-user',$data);
		$this->load->view('admin/inc/footer');
		 


	}


	public function add_area()
	{
		 

	
 
		 $this->form_validation->set_rules('area_name', 'Area Name', 'required');
 

		if ($this->form_validation->run() == FALSE)
		{
 	
		 	 
		$this->load->view('admin/inc/header');
		$this->load->view('admin/add-area');
		$this->load->view('admin/inc/footer');
		 

		}else{
 				

			
				$idata['area_name']=$this->input->post('area_name');
				 
				$this->db->insert('tbl_area',$idata);
			  
				$msg='<div class="alert alert-success">Area Added</div>';
				
				$this->session->set_flashdata('message',$msg);
				
				
				redirect($_SERVER['HTTP_REFERER']);

				 
		}

	}


	public function view_area()
	{
		 
		$data['area']=$this->db->get('tbl_area')->result_array();
		 	
		$this->load->view('admin/inc/header');
		$this->load->view('admin/view-area',$data);
		$this->load->view('admin/inc/footer');
		 


	}

	public function delete_area($id)
	{
		 
		$this->db->where('a_id',$id)->delete('tbl_area');
		 	
		redirect($_SERVER['HTTP_REFERER']);
		 


	}

	public function add_gallery()
	{
		 
 
		 	 
		$this->load->view('admin/inc/header');
		$this->load->view('admin/add-gallery');
		$this->load->view('admin/inc/footer');
		 
 

			if(!empty($_FILES) && ($_FILES['user_image']['name'])){
			

			  $config['upload_path'] = 'img/';
			  $config['allowed_types'] = 'gif|jpg|png|jpeg';
			  $this->load->library('upload', $config);
			   if (!$this->upload->do_upload('user_image')) {
			     $this->session->set_flashdata('message', $this->upload->display_errors());
			 
					redirect('Admin/add-gallery/'.$id);
			 } else {
			  $avatar = $this->upload->data();
			  $user_image = $avatar['file_name'];

			  $idata['g_image']=$user_image;

	 			$this->db->insert('tbl_gallery',$idata);

				$message='<div class="alert alert-success">Gallery Added Successfully</div>';

				$this->session->set_flashdata('message',$message);

				redirect('Admin/add-gallery/');
 

			 }



			} 

			/////////////////////////---- FILE ADDING CODE -----////////////////////////////

   

	}

	public function view_gallery()
	{
		 
		$data['gallery']=$this->db->get('tbl_gallery')->result_array();
		 	
		$this->load->view('admin/inc/header');
		$this->load->view('admin/view-gallery',$data);
		$this->load->view('admin/inc/footer');
		 


	}

	public function edit_gallery($id)
	{
 

		 $data['gallery']=$this->db->where('g_id',$id)->get('tbl_gallery')->row_array();
			
		 	 
		$this->load->view('admin/inc/header');
		$this->load->view('admin/edit-gallery',$data);
		$this->load->view('admin/inc/footer');
		 
 

			if(!empty($_FILES) && ($_FILES['user_image']['name'])){
			

			  $config['upload_path'] = 'img/';
			  $config['allowed_types'] = 'gif|jpg|png|jpeg';
			  $this->load->library('upload', $config);
			   if (!$this->upload->do_upload('user_image')) {
			     $this->session->set_flashdata('message', $this->upload->display_errors());
			 
					redirect('Admin/edit-gallery/'.$id);
			 } else {
			  $avatar = $this->upload->data();
			  $user_image = $avatar['file_name'];

			  $idata['g_image']=$user_image;

			    unlink('img/'.$old_image.'');

			    $this->db->where('g_id',$id)->update('tbl_gallery',$idata);

				$message='<div class="alert alert-success">Gallery Updated Successfully</div>';

				$this->session->set_flashdata('message',$message);

				redirect('Admin/edit-gallery/'.$id);

			 }

			} 

			/////////////////////////---- FILE ADDING CODE -----////////////////////////////

 
	}


	public function delete_gallery($id)
	{
		 
		$this->db->where('g_id',$id)->delete('tbl_gallery');
		 	
		redirect($_SERVER['HTTP_REFERER']);
		 


	}


	public function add_news()
	{
		 

	
 
		 $this->form_validation->set_rules('title', 'News Title', 'required');
		 $this->form_validation->set_rules('description', 'News description', 'required');
 

		if ($this->form_validation->run() == FALSE)
		{
 	
		 	 
		$this->load->view('admin/inc/header');
		$this->load->view('admin/add-news');
		$this->load->view('admin/inc/footer');
		 

		}else{
 				


			
				$idata['title']=$this->input->post('title');
				$idata['description']=$this->input->post('description');
				 
				$this->db->insert('tbl_news',$idata);
			  
				$msg='<div class="alert alert-success">News Added</div>';
				
				$this->session->set_flashdata('message',$msg);
				
				
				redirect($_SERVER['HTTP_REFERER']);

				 
		}

	}


	public function edit_news($id)
	{
		 

	
 
		 $this->form_validation->set_rules('title', 'News Title', 'required');
		 $this->form_validation->set_rules('description', 'News description', 'required');
 

		if ($this->form_validation->run() == FALSE)
		{
 		
 		$data['news']=$this->db->where('n_id',$id)->get('tbl_news')->row_array();
		 	 
		$this->load->view('admin/inc/header');
		$this->load->view('admin/edit-news',$data);
		$this->load->view('admin/inc/footer');
		 

		}else{
 				


			
				$idata['title']=$this->input->post('title');
				$idata['description']=$this->input->post('description');
				 
				$this->db->where('n_id',$id)->update('tbl_news',$idata);
			  
				$msg='<div class="alert alert-success">News Updated</div>';
				
				$this->session->set_flashdata('message',$msg);
				
				
				redirect($_SERVER['HTTP_REFERER']);

				 
		}

	}


	public function view_news()
	{
		 
		$data['news']=$this->db->get('tbl_news')->result_array();
		 	
		$this->load->view('admin/inc/header');
		$this->load->view('admin/view-news',$data);
		$this->load->view('admin/inc/footer');
		 


	}

	public function delete_news($id)
	{
		 
		$this->db->where('n_id',$id)->delete('tbl_news');
		 	
		redirect($_SERVER['HTTP_REFERER']);
		 


	}


	public function settings()
	{
		 

	

		 $this->form_validation->set_rules('user_name', 'User Name', 'required');
		 $this->form_validation->set_rules('mobile', 'Admin User Name', 'required');
		
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		$this->form_validation->set_rules('v_password', 'Verify password', 'required|matches[password]');
 
 
  

		if ($this->form_validation->run() == FALSE)
		{

	 	$data['user']=$this->db->where('id',$this->session->userdata('id'))->get('tbl_user')->row_array();
			
		$this->load->view('admin/inc/header');
		$this->load->view('admin/settings',$data);
		$this->load->view('admin/inc/footer');
		 

		}else{

			$idata['name']=$this->input->post('user_name');
			$idata['mobile']=$this->input->post('mobile');
			$idata['password']=$this->input->post('password');

 
			$this->db->where('id',$this->session->userdata('id'))->update('tbl_user',$idata);

			$message='<div class="alert alert-success">Account Updated Successfully</div>';

			$this->session->set_flashdata('message',$message);

			redirect('Admin/settings');

		}
		 

 

		 

	}



	public function add_admin()
	{
		 

	

		 $this->form_validation->set_rules('user_name', 'User Name', 'required');
		 $this->form_validation->set_rules('mobile', 'Admin User Name', 'required');
		
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		$this->form_validation->set_rules('v_password', 'Verify password', 'required|matches[password]');
 
 
  

		if ($this->form_validation->run() == FALSE)
		{

	 	$data['user']=$this->db->where('id',$this->session->userdata('id'))->get('tbl_user')->row_array();
			
		$this->load->view('admin/inc/header');
		$this->load->view('admin/add-admin',$data);
		$this->load->view('admin/inc/footer');
		 

		}else{

			$idata['name']=$this->input->post('user_name');
			$idata['mobile']=$this->input->post('mobile');
			$idata['password']=$this->input->post('password');
			$idata['type']='admin';

 
			$this->db->insert('tbl_user',$idata);

			$message='<div class="alert alert-success">Account Added Successfully</div>';

			$this->session->set_flashdata('message',$message);

			redirect('Admin/add-admin');

		}
		 

 

		 

	}



	public function view_admin()
	{
		 
		$data['user']=$this->db->where('type','admin')->get('tbl_user')->result_array();
		 	
		$this->load->view('admin/inc/header');
		$this->load->view('admin/view-admin',$data);
		$this->load->view('admin/inc/footer');
		 


	} 


	public function add_relief_type()
	{
		 

	
 
		 $this->form_validation->set_rules('relief_type', 'Relief Type Name', 'required');
 

		if ($this->form_validation->run() == FALSE)
		{
 	
		 	 
		$this->load->view('admin/inc/header');
		$this->load->view('admin/add-relief-type');
		$this->load->view('admin/inc/footer');
		 

		}else{
 				

			
				$idata['relief_type']=$this->input->post('relief_type');
				 
				$this->db->insert('tbl_relief_type',$idata);
			  
				$msg='<div class="alert alert-success">Relief Type Added</div>';
				
				$this->session->set_flashdata('message',$msg);
				
				
				redirect($_SERVER['HTTP_REFERER']);

				 
		}

	}







	public function view_relief_type()
	{
		 
		$data['relief_type']=$this->db->get('tbl_relief_type')->result_array();
		 	
		$this->load->view('admin/inc/header');
		$this->load->view('admin/view-relief-type',$data);
		$this->load->view('admin/inc/footer');
		 


	}

	public function delete_relief_type($id)
	{
		 
		$this->db->where('rt_id',$id)->delete('tbl_relief_type');
		 	
		redirect($_SERVER['HTTP_REFERER']);
		 


	}



	public function view_relief_request()
	{
		 
		$data['relief']=$this->db->from('tbl_request,tbl_user,tbl_relief_type')->where('tbl_request.user_id=tbl_user.id')->where('tbl_request.relief_type_id=tbl_relief_type.rt_id')->where('approve','0')->get()->result_array();
		 	
		$this->load->view('admin/inc/header');
		$this->load->view('admin/view-request',$data);
		$this->load->view('admin/inc/footer');
		 


	}

		public function view_approved_request()
	{
		 
		$data['relief']=$this->db->from('tbl_request,tbl_user,tbl_relief_type')->where('tbl_request.user_id=tbl_user.id')->where('tbl_request.relief_type_id=tbl_relief_type.rt_id')->where('approve','1')->get()->result_array();
		 	
		$this->load->view('admin/inc/header');
		$this->load->view('admin/view-request',$data);
		$this->load->view('admin/inc/footer');
		 


	}


		public function view_rejected_request()
	{
		 
		$data['relief']=$this->db->from('tbl_request,tbl_user,tbl_relief_type')->where('tbl_request.user_id=tbl_user.id')->where('tbl_request.relief_type_id=tbl_relief_type.rt_id')->where('approve','1')->get()->result_array();
		 	
		$this->load->view('admin/inc/header');
		$this->load->view('admin/view-request',$data);
		$this->load->view('admin/inc/footer');
		 


	}

	public function approve_request($approve,$id)
	{
		 
		$this->db->where('rq_id',$id)->set('approve',$approve)->update('tbl_request');
		 	
		redirect($_SERVER['HTTP_REFERER']);
		 


	}




	public function add_relief_pattern()
	{
		 

	
 
		 $this->form_validation->set_rules('relief_pattern', 'Relief Pattern', 'required');
 

		if ($this->form_validation->run() == FALSE)
		{
 	
		 	 
		$this->load->view('admin/inc/header');
		$this->load->view('admin/add-relief-pattern');
		$this->load->view('admin/inc/footer');
		 

		}else{
 				

			
				$idata['relief_pattern']=$this->input->post('relief_pattern');
				 
				$this->db->insert('tbl_relief_pattern',$idata);
			  
				$msg='<div class="alert alert-success">Relief Type Added</div>';
				
				$this->session->set_flashdata('message',$msg);
				
				
				redirect($_SERVER['HTTP_REFERER']);

				 
		}

	}







	public function view_relief_pattern()
	{
		 
		$data['relief_pattern']=$this->db->get('tbl_relief_pattern')->result_array();
		 	
		$this->load->view('admin/inc/header');
		$this->load->view('admin/view-relief-pattern',$data);
		$this->load->view('admin/inc/footer');
		 


	}

	public function delete_relief_pattern($id)
	{
		 
		$this->db->where('rpid',$id)->delete('tbl_relief_pattern');
		 	
		redirect($_SERVER['HTTP_REFERER']);
		 


	}



	public function add_relief_distribution()
	{
		 

	
 
		 $this->form_validation->set_rules('relief_pattern', 'Relief Pattern', 'required');
		 $this->form_validation->set_rules('amount', 'Relief Amount', 'required|is_numeric');
		 $this->form_validation->set_rules('particular', 'Relief Particular', 'required');
		 $this->form_validation->set_rules('area_id', 'Area', 'required');
 

		if ($this->form_validation->run() == FALSE)
		{
 	
		$data['relief_pattern']=$this->db->get('tbl_relief_pattern')->result_array();
		$data['area']=$this->db->get('tbl_area')->result_array();
		  	 
		$this->load->view('admin/inc/header');
		$this->load->view('admin/add-relief-distribution',$data);
		$this->load->view('admin/inc/footer');
		 

		}else{
 				

			
				
				$user=$this->db->where('area_id',$this->input->post('area_id'))->get('tbl_user')->result_array();
				$total=$this->db->where('area_id',$this->input->post('area_id'))->get('tbl_user')->num_rows();

				if($total>0){

				$idata['relief_pattern']=$this->input->post('relief_pattern');
				$idata['r_amount']=$this->input->post('amount');
				$idata['particular']=$this->input->post('particular');
				$idata['area_id']=$this->input->post('area_id');
				 
				$this->db->insert('tbl_relief',$idata);

				foreach ($user as $in) {

				$idata2=array();

				$idata2['relief_pattern']=$this->input->post('relief_pattern');
				$idata2['amount']=number_format(($this->input->post('amount')/$total),2);
				$idata2['particular']=$this->input->post('particular');
				 $idata2['user_id']=$in['id'];
				 
				$this->db->insert('tbl_relief_distribution',$idata2);

				}

				

				$msg='<div class="alert alert-success">Relief Added</div>';
				
				$this->session->set_flashdata('message',$msg);

				}else{

				$msg='<div class="alert alert-danger">Sorry No user In this Area</div>';
				
				$this->session->set_flashdata('message',$msg);


				}


			  
				
				
				
				redirect($_SERVER['HTTP_REFERER']);

				 
		}

	}

	public function view_relief()
	{
		 
		$data['relief']=$this->db->from('tbl_relief,tbl_area')->where('tbl_relief.area_id=tbl_area.a_id')->get()->result_array();
		 	
		$this->load->view('admin/inc/header');
		$this->load->view('admin/view-relief',$data);
		$this->load->view('admin/inc/footer');
		 


	}

	public function view_relief_distribution()
	{
		 
		$data['relief']=$this->db->from('tbl_relief_distribution,tbl_user,tbl_area')->where('tbl_relief_distribution.user_id=tbl_user.id')->where('tbl_user.area_id=tbl_area.a_id')->get()->result_array();
		 	
		$this->load->view('admin/inc/header');
		$this->load->view('admin/view-relief-distribution',$data);
		$this->load->view('admin/inc/footer');
		 


	}


	public function edit_relief_type($id)
	{
		 

	
 
		 $this->form_validation->set_rules('relief_type', 'Relief Type', 'required');
		 $this->form_validation->set_rules('attachment_text', 'Attachment Text', 'required');
 

		if ($this->form_validation->run() == FALSE)
		{
 		
 		$data['relief']=$this->db->where('rt_id',$id)->get('tbl_relief_type')->row_array();
		 	 
		$this->load->view('admin/inc/header');
		$this->load->view('admin/edit-relief-type',$data);
		$this->load->view('admin/inc/footer');
		 

		}else{
 				


			
				$idata['relief_type']=$this->input->post('relief_type');
				$idata['attachment_text']=$this->input->post('attachment_text');
				 
				$this->db->where('rt_id',$id)->update('tbl_relief_type',$idata);
			  
				$msg='<div class="alert alert-success">Relief Type Updated</div>';
				
				$this->session->set_flashdata('message',$msg);
				
				
				redirect($_SERVER['HTTP_REFERER']);

				 
		}

	}
	
	 
	
}