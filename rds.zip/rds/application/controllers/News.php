<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class News extends CI_Controller {

	
	public function index()
	{
		 
		$data['news']=$this->db->get('tbl_news')->result_array();
		 
		$this->load->view('inc/header');
		$this->load->view('news',$data);
		$this->load->view('inc/footer');
		 
		 
 

		 

	}


	public function detail($id)
	{
		 
		$data['news']=$this->db->where('n_id',$id)->get('tbl_news')->row_array();
		$data['comments']=$this->db->from('tbl_comment,tbl_user')->where('tbl_comment.user_id=tbl_user.id')->where('news_id',$id)->get()->result_array();

		$this->form_validation->set_rules('comment', 'Comment', 'required');

		if ($this->form_validation->run() == FALSE)
		{
		 
		$this->load->view('inc/header');
		$this->load->view('news-detail',$data);
		$this->load->view('inc/footer');
		
		}else{


			
			if($this->session->userdata('id')&&($this->session->userdata('type')=='user')){


				$idata['comment']=$this->input->post('comment');
				$idata['user_id']=$this->session->userdata('id');
				$idata['news_id']=$id;

				$this->db->insert('tbl_comment',$idata);


				$message='<div class="alert alert-success">Comment Added</div>';

				$this->session->set_flashdata('message',$message);

				redirect($_SERVER['HTTP_REFERER']);
			 
			}else{

				$message='<div class="alert alert-danger">Please Login</div>';

				$this->session->set_flashdata('message',$message);

				redirect($_SERVER['HTTP_REFERER']);

			}


		}
		 
 

		 

	}
	
	 
	
}