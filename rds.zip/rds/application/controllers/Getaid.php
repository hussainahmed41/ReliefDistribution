<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Getaid extends CI_Controller {

	
	public function index()
	{
		 
		$this->form_validation->set_rules('rq_amount', 'Comment', 'required');
		$this->form_validation->set_rules('reason', 'Reason', 'required');
		$this->form_validation->set_rules('relief_type_id', 'Relief Type', 'required');

		if ($this->form_validation->run() == FALSE)
		{

		$data['relief_type']=$this->db->get('tbl_relief_type')->result_array();
		
		$this->load->view('inc/header');
		$this->load->view('get-aid',$data);
		$this->load->view('inc/footer');
		
		}else{


			
			if($this->session->userdata('id')&&($this->session->userdata('type')=='user')){


				$idata['rq_amount']=$this->input->post('rq_amount');
				$idata['reason']=$this->input->post('reason');
				$idata['relief_type_id']=$this->input->post('relief_type_id');
				$idata['user_id']=$this->session->userdata('id');
			 

				$this->db->insert('tbl_request',$idata);

				$last_id= $this->db->insert_id();

				if($_FILES['files']['name']){

					$count = count($_FILES['files']['name']);

					for($i=0;$i<$count;$i++){

					if(!empty($_FILES['files']['name'][$i])){

							$_FILES['file']['name'] = $_FILES['files']['name'][$i];
							$_FILES['file']['type'] = $_FILES['files']['type'][$i];
							$_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
							$_FILES['file']['error'] = $_FILES['files']['error'][$i];
							$_FILES['file']['size'] = $_FILES['files']['size'][$i];
							$config['upload_path'] = 'img/'; 
							$config['allowed_types'] = 'jpg|jpeg|pdf|PDF|png|gif';
							$config['max_size'] = '5000';
							$config['file_name'] = $_FILES['files']['name'][$i];

							$this->load->library('upload',$config); 

							if($this->upload->do_upload('file')){

							$uploadData = $this->upload->data();
							$filename = $uploadData['file_name'];
							$data['totalFiles'][] = $filename;

							$gdata['file_path']=$filename;
							$gdata['rqsid']= $last_id;

							$this->db->insert('tbl_attachment',$gdata);

								 

							}
						}
					}

				  }


				$message='<div class="alert alert-success">Request Added</div>';

				$this->session->set_flashdata('message',$message);

				redirect($_SERVER['HTTP_REFERER']);
			 
			}else{

				$message='<div class="alert alert-danger">Please Login</div>';

				$this->session->set_flashdata('message',$message);

				redirect($_SERVER['HTTP_REFERER']);

			}


		}


	}

	public function loadAidText($rt_id="")
	{
		if($rt_id){
			$result=$this->db->where('rt_id',$rt_id)->get('tbl_relief_type')->row_array()['attachment_text'];

			echo $result;
		}else{

			echo 'Please Select an Aid Type';
		}
		
		

	}


	 
	
	 
	
}