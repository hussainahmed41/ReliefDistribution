<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	function __construct() {

        parent::__construct();

		date_default_timezone_set('Asia/Dhaka');
		
        if($this->session->userdata('type')=='user'){
			
		}else{
		redirect('welcome');
		}


    }


	public function index()
	{
		 
		$data['request']=$this->db->where('user_id',$this->session->userdata('id'))->where('approve','0')->get('tbl_request')->num_rows();
		$data['approved']=$this->db->where('user_id',$this->session->userdata('id'))->where('approve','1')->get('tbl_request')->num_rows();
		$data['rejected']=$this->db->where('user_id',$this->session->userdata('id'))->where('approve','2')->get('tbl_request')->num_rows();
		$data['amount']=$this->db->select('sum(rq_amount) as amount')->where('user_id',$this->session->userdata('id'))->where('approve','1')->get('tbl_request')->row_array()['amount'];
		 
		$this->load->view('user/inc/header');
		$this->load->view('user/dashboard',$data);
		$this->load->view('user/inc/footer');
		 


	}

 
	 


	public function settings()
	{
		 

	

		 $this->form_validation->set_rules('user_name', 'User Name', 'required');
		 $this->form_validation->set_rules('mobile', 'Mobile', 'required|is_numeric');
		
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		$this->form_validation->set_rules('v_password', 'Verify password', 'required|matches[password]');
 
 
  

		if ($this->form_validation->run() == FALSE)
		{

	 	$data['user']=$this->db->where('id',$this->session->userdata('id'))->get('tbl_user')->row_array();
			
		$this->load->view('user/inc/header');
		$this->load->view('user/settings',$data);
		$this->load->view('user/inc/footer');
		 

		}else{

			$idata['name']=$this->input->post('user_name');
			$idata['mobile']=$this->input->post('mobile');
			$idata['password']=$this->input->post('password');

 
			$this->db->where('id',$this->session->userdata('id'))->update('tbl_user',$idata);

			$message='<div class="alert alert-success">Account Updated Successfully</div>';

			$this->session->set_flashdata('message',$message);

			redirect('user/settings');

		}
		 

 

		 

	}

 




	public function view_relief_request()
	{
		 
		$data['relief']=$this->db->from('tbl_request,tbl_user,tbl_relief_type')->where('tbl_request.user_id=tbl_user.id')->where('tbl_request.user_id',$this->session->userdata('id'))->where('tbl_request.relief_type_id=tbl_relief_type.rt_id')->where('approve','0')->get()->result_array();

		$data['attachment']=$this->db->get('tbl_attachment')->result_array();
		 
		 	
		$this->load->view('user/inc/header');
		$this->load->view('user/view-request',$data);
		$this->load->view('user/inc/footer');
		 


	}

		public function view_approved_request()
	{
		 
		$data['relief']=$this->db->from('tbl_request,tbl_user,tbl_relief_type,tbl_area')->where('tbl_request.user_id=tbl_user.id')->where('tbl_area.a_id=tbl_user.area_id')->where('tbl_request.user_id',$this->session->userdata('id'))->where('tbl_request.relief_type_id=tbl_relief_type.rt_id')->where('approve','1')->get()->result_array();

	 	
		$this->load->view('user/inc/header');
		$this->load->view('user/view-request',$data);
		$this->load->view('user/inc/footer');
		 


	}


	public function view_rejected_request()
	{
		 
		$data['relief']=$this->db->from('tbl_request,tbl_user,tbl_relief_type')->where('tbl_request.user_id=tbl_user.id')->where('tbl_request.user_id',$this->session->userdata('id'))->where('tbl_request.relief_type_id=tbl_relief_type.rt_id')->where('approve','2')->get()->result_array();

		 	
		$this->load->view('user/inc/header');
		$this->load->view('user/view-request',$data);
		$this->load->view('user/inc/footer');
		 


	}


	public function view_relief_distribution()
	{
		 
		$data['relief']=$this->db->from('tbl_relief_distribution,tbl_user,tbl_area')->where('tbl_relief_distribution.user_id=tbl_user.id')->where('tbl_user.area_id=tbl_area.a_id')->where('user_id',$this->session->userdata('id'))->get()->result_array();
		 	
		$this->load->view('user/inc/header');
		$this->load->view('user/view-relief-distribution',$data);
		$this->load->view('user/inc/footer');
		 


	}

	 


	 
	
	 
	
}